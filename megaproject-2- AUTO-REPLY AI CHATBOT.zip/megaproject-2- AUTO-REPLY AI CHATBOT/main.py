import pyautogui
while True:
 a = pyautogui.position()
 print(a)
#  1439 , 1049
#  1022, 154 to 1881 ,990
1431,1050
x = 1319, y = 120
X = 1556 , y = 435