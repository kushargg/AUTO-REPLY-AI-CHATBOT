import pyautogui
import time
import clipboard

# Coordinates for the first click
icon_x = 1431
icon_y = 1050

# Coordinates for selecting the text
start_x = 1319
start_y = 120
end_x = 1556
end_y = 435

# Delay between actions (adjust as needed)
delay = 0.5 


def copy_text():
  """
  Clicks on an icon, selects text within specified coordinates, 
  and copies the selected text to the clipboard.

  Returns:
      str: The copied text.
  """

  try:
      # Click on the icon
      pyautogui.click(icon_x, icon_y)
      time.sleep(delay)

      # Select the text
      pyautogui.moveTo(start_x, start_y)
      pyautogui.dragTo(end_x, end_y, duration=1) 
      time.sleep(delay)

      # Copy the selected text to the clipboard
      pyautogui.hotkey('ctrl', 'c')
      time.sleep(delay)

      # Get the copied text from the clipboard using the clipboard module
      copied_text = clipboard.paste()

      return copied_text

  except Exception as e:
      print(f"An error occurred: {e}")
      return None

# Get the copied text
text_data = copy_text()

# Print the copied text (optional)
if text_data:
  print(f"Copied text:\n{text_data}")